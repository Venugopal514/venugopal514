import React,{useState } from "react"
import axios from "axios"
import '../../Components/styles.css'

const Adduser =() =>
{
    const [state,setState]=useState({
        name:"",
        username:"",
        email : ""
    });
    function submit(e){
        e.preventdefault();
        axios.post('https://jsonplaceholder.typicode.com/users',{
            name: state.name,
            username:state.username,
            email:state.email
        }).then(res=>{console.log(res.state)})
    }
    
    function handleChange (e) {
        const newdata ={...state}
        newdata[e.target.id]=e.target.value
        setState(newdata)
        console.log(newdata)

    }
    return(
        <div>
        <form onSubmit={(e)=>submit(e)} className="form">
            <label>Name</label>
            <input type='Text' onChange={handleChange} id="name" value={state.name} placeholder='Name'/><br/>
            <label>userName</label>
            <input type='Text' onChange={handleChange} id="username" value={state.username} placeholder='UserName'/><br/>
            <label>Email</label>
            <input type='Text' onChange={handleChange} id="email" value={state.email} placeholder='Email'/><br/>
            <button type="submit">Register</button>
        </form>
        </div>
    )

}
export default Adduser;
