import React from "react";
import { Link } from "react-router-dom";
import '../NavBar/styles.css';

const Navbar =() =>
{
    return<>
    <div className="navigationmenu">
            <Link to="/Components/UserDetails" className="link">User Details</Link>
            <Link to ="Components/Adduser" className="link">Add User</Link>
    </div>
    </>
}
export default Navbar;