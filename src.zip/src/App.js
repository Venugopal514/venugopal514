import "./App.css";
import UserDetails from "./Components/UserDetails";
import { Route, Routes } from "react-router-dom";
import Navbar from "./Components/NavBar";
import Adduser from "./Components/AddUser";

function App() {
  return (
    <>
      <div>
        <Navbar />
        <Adduser />
        <Routes>
          <Route path="/Components/UserDetails" element={<UserDetails />} />
          <Route path="/Components/AddUser" element={<Adduser />} />
        </Routes>
      </div>
    </>
  );
}
export default App;
